class Student:
    def __init__(self, name, korean, math, english, science):
        self.name = name
        self.korean = korean
        self.math = math
        self.english = english
        self.science = science
        print("{} 인스턴스가 생성되었습니다.".format(name))

    def get_sum(self):
        return self.korean + self.math + self.english + self.science

    def get_avg(self):
        return self.get_sum() / 4
    
    def obj_print(self):
        return "{}\t{}\t{}\t".format(self.name, self.get_sum(), self.get_avg())
        
    def __del__(self):
        print("{} 인스턴스가 제거되었습니다.".format(self.name))

students = [
    Student("윤인성", 87, 98, 88 ,95),
    Student("연하진", 92, 98, 96 ,98),
    Student("구지연", 76, 96, 94 ,90),
    Student("나선주", 98, 92, 96 ,92),
    Student("윤아린", 95, 98, 98 ,98),
    Student("윤명월", 64, 88, 92 ,92)
]

print("이름\t총점\t평균")

for student in students:
    print(student.obj_print())
