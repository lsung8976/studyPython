
hakbun = input("학번을 입력하세요 : ")

number = "{:02d}".format(int(hakbun[2])*10 + int(hakbun[3]))

if(number <= 10) :
    print("화석입니다.")
else:  
    print(number, "학번입니다.")
