numbers = [103, 52, 273, 32, 77]

print(max(numbers))
print(min(numbers))
print(sum(numbers))
