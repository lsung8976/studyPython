array = []

for i in range(0, 20, 2):
    array.append(i * i)

print(array)

array1 = [i * i for i in range(0, 20, 2)]

print(array1)

