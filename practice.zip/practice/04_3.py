a = range(5)
print(list(range(10)))
print(type(range(0,5)))
print(list(range(0,10,2)))

n = 10
a = range(0, int(n/2))


raise NotImplementedError