class Student:
    def __init__(self):
        pass

student = Student()

print("isinstance(student, Student):", isinstance(student, Student))

print(type(student) == Student)