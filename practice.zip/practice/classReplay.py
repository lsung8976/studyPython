class position:

    DB = [] #클래스 변수
    age = 23 # + 23

    @classmethod #클래스 함수 <3> @classmethod, cls
    def printAllInfo(cls):
        print("당신의 나이는{}입니다.".format(cls. age))



    def __init__(self, x, y): # 생성자
        self.x = x
        self.y = y
        #self.length = sqrt(x, y) 메소드 변수

    #메소드 함수 = 인스턴스 함수<1>
    def calcLength(self): 
        return (self.x ** 2 + self.y ** 2) ** (1/2)

namhyo = position(10, 20)
sungjoon = position(20, 40) #x, y(생성자로 생성된 변수) , age(클래스변수로 생성된 변수)


print(namhyo.calcLength())

def calcAdder(a, b):#일반함순<2>
    return a + b
"""
print(calcAdder(20, 30))


print(position.age) #클래스변수접근
position.age += 23
print(position.age)

sungjoon.age += 1
print(sungjoon.age)
print(namhyo.age) #???"""

position.printAllInfo()