"""array = [123, 23 ,103, "문자열", True, False]

print(array[-1])
print(array[0])
print(array[-2])

print(array[3][0])
print(array[3])

list_a = [[1,2,3], [1,2,3],[7,9,10]]

list_a.append(4)

print(list_a)

list_a.insert(0,10)

print(list_a)

list_a = [1,2,3]

print(list_a)

list_b = [4,5,6]

list_a.extend(list_b)

print(list_a)

numbers = [1,2,3,4,5,6,7,8,9]

output = [[], [], []]


for number in numbers:
    output[numbers[number]].append(number)


print(output)"""

print("3".zfill(1))