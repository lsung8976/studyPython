'''
x = 10
y = 2
if x > 4:
    if y > 2:
        print(x * y)
else:
    print(x + y)
'''

str_input = input("태어난 해를 입력해 주세요")
birth_year = int(str_input) % 12

if birth_year == 0:
    print("원숭이 띠 입니다.")
elif birth_year == 1:
    print("닭 띠 입니다.")
elif birth_year == 2:
    print("개 띠 입니다.")
elif birth_year == 3:
    print("돼지 띠 입니다.")
elif birth_year == 4:
    print("쥐 띠 입니다.")
elif birth_year == 5:
    print("소 띠 입니다.")
elif birth_year == 6:
    print("범 띠 입니다.")
elif birth_year == 7:
    print("토끼 띠 입니다.")
elif birth_year == 8:
    print("용 띠 입니다.")
elif birth_year == 9:
    print("뱀 띠 입니다.")
elif birth_year == 10:
    print("말 띠 입니다.")
elif birth_year == 11:
    print("양 띠 입니다.")