#1
def flatten(data):
    output = []
    for num in data:
        if type(num) == list:
            output += flatten(num)
        else:
            output.append(num)
    return output

example = [[1, 2, 3], [4, [5, 6]], 7 ,[8, 9]]

print("원본 :", example)
print("변환 :", flatten(example))

#2
"""
min_p = 2
max_p = 10
total_p = 100
memo = {}

def prob(a, b):
    key = str([a, b])

    #종료조건
    if key in memo:

    if a < 0:
        return 0
    if b == 0:
        return 1
    #재귀처리

    #메모화처리

    #종료

print(prob(total_p, max_p))"""