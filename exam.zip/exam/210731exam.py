"""
학생인지 성인인지
잔여금액
나이
이름

탑승했을때
하차했을때
환승했을때
충전할때

카드정보확인
"""

class TmoneyCard:

    #클래스 변수
    teenBusFee = 200
    teenSubWayFee = 400
    adultBusFee = 500
    adultSubwayFee = 800

    def __init__(self, name, age, money):
        self.name = name
        self.age = age
        self.money = money
        self.time = 0
        if(age < 19):
            self.job = "청소년"
        else:
            self.job = "성인"

    def to_string(self):
        return "{}\t{}\t{}\t{}".format(self.name, self.age, self.money, self.job)

    def addMoney(self, bill):
        self.money += bill
    
    def getOnBus(self):
        if(self.job == "청소년"):
            self.money -= teenBusFee
        elif(self.job == "성인"):
            self.money -= adultBusFee

    def getOnSubway(self):
        if(self.job == "청소년"):
            self.money -= teenSubWayFee
        elif(self.job == "성인"):
            self.money -= teenBusFee
    
    def transfer()