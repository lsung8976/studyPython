"""import datetime

now1 = datetime.datetime.now()

print("현재시간")
print("{}년 {}월 {}일".format(now1.year, now1.month, now1.day))

year = int(input("년 입력>:"))
month = int(input("월 입력>:"))
day = int(input("일 입력>:"))
after = datetime.datetime(year, month, day)

dday = after - now

print("D - day ")
print("D - {}".format(dday.days))"""

import datetime

now=datetime.datetime.now()
test_date=datetime.datetime(2021,8,18,10,0,0)

sugang=test_date-now
sugang_a=sugang.seconds//3600
sugang_b=(sugang.seconds%3600)//60
sugang_c=(sugang.seconds%3600)%60

print(sugang)
print("수강신청까지 남은 시간은:",\
      "{}일 {}시간 {}분 {}초".format(sugang.days,sugang.,sugang_b,sugang_c)+"입니다")