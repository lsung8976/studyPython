print("{:b}".format(10))


print(int("1010", 2))


output = [ i for i in range(1, 100) if ("{:b}".format(i)).count("0") == 1 ]


for i in output:
    print("{} : {}".format(i, "{:b}".format(i)))
print("합계:", sum(output))