#1번
numbers = [1,2,3,4,5]

print("::".join(str(i) for i in numbers)) #join을 사용시에는 문자열 형으로 파라미터를 받아야함!


#2번
numbers = list(range(1, 10 + 1))

print("#홀수만 추출하기")
print(list(filter(lambda x : x % 2 , numbers)))
print()

print("#3 이상, 7 미만 추출하기")
print(list(filter(lambda x : 3 <= x < 7, numbers)))
print()

print("#제곱해서 50 미만 추출하기")
print(list(filter(lambda x : (x ** 2) < 50, numbers)))
print()