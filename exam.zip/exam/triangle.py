from random import *

case = []

while(len(case) != 6):

    Ball = randrange(1, 46)

    for i in range(len(case)):
        if(Ball == case[i]):
            print("수가 중복되었습니다. {}".format(Ball))
            case.remove(Ball)
    
    case.append(Ball)

print(case)
