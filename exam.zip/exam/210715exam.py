"""#Range 함수 만들어보기

def Range(start_v = 0, end_v = 0, step_v = 1):
    output = []
    i = start_v
    while(i < end_v):
        output.append(i)
        i += step_v
    return output

print(Range(4, 10))

for i in Range(end_v = 10):
    print(i)
"""
#Range 함수 만들어보기
def Range(*elements):
    #기본 변수
    size = len(elements)
    start = 0
    step = 1
    output = []

    if size == 3:   #매개변수가 3개일때
        start = elements[0]
        end = elements[1]
        step = elements[2]
    elif size == 2: #매개변수가 2개일때
        start = elements[0]
        end = elements[1]
    elif size == 1: #매개변수가 1개일때
        end = elements[0]
    else:
        return

    #reversedRange 구현
    if start > end:
        i = start - 1
        while(i >= end):
            output.append(i)
            i += step
        return output
    elif start < end:
        i = start
        while(i < end):
            output.append(i)
            i += step
        return output
    else:
        return


print(Range(10))
print(Range(10, 0, -1))


for i in Range(10, 0, -1):
    print(i)