#1번 문제

def f(x):
    return 2 * x + 1
print(f(10))

def f(x):
    return x ** 2 + x * 2 + 1
print(f(10))

#2번 문제
def mul(*value):
    output = 1
    for i in value:
        output *= i
    return output

print(mul(5, 7, 9, 10))

def function(valueA, valueB, *values):
    for i in values:
        print(i)

function(1, 2, 3, 4, 5)