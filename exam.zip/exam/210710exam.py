#거스름돈 출력 프로그램

money = int(input("금액을 입력하세요 : "))
wallet = {}
money_paper = [10000, 5000, 1000, 500]

for i in money_paper:
    wallet[i] = money // i
    money -= wallet[i] * i

print(wallet)