#함수를 정의합니다.
def return_test():
    print("A 위치입니다.")
    return
    pritn("B 위치입니다.")

#함수를 호출합니다.
return_test()



def return_test():
    print("A 위치입니다.")
    return
    print("B 위치입니다.")

return_test()

def return_test():
    return 

value = return_test()
print(value)