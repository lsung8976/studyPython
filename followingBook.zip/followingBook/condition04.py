number = input("정수입력> ")
number = int(number)

#조건문을 사용합니다.
if number % 2 == 0:
    #조건이 참일 때, 즉 짝수 조건
    print("짝수입니다.")
else:
    #조건이 거짓일 때, 즉 홀수 조건
    print("홀수입니다.")