[a, b] = [10, 20]
(c, d) = (10, 20)

print("a :", a)
print("b :", b)
print("c :", c)
print("d :", d)
