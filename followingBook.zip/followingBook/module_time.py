import time

print("지금부터 5초 동안 정지합니다.")

time.sleep(5)
print("프로그램을 종료합니다.")