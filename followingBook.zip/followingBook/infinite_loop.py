while True:
    print(".", end = "")