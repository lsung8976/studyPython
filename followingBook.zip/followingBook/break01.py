numbers = [5, 15, 6, 20, 7, 25]

for number in numbers:
    if number < 10:
        break
    print(number)