#역반복문
for i in range(4, 0 - 1, -1):
    #출력합니다.
    print("현재 반복 변수: {}".format(i))