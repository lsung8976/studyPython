try:
    #파일을 엽니다.
    file = open("info.txt", "w")
    #여러가지 처리를 수행합니다.
    exception.appeal() #
    #파일을 닫습니다.
    file.close()
except Exception as e:
    print(e)
finally:
    file.close()

print("#파일이 제대로 닫혔는지 확인하기")
print("file.closed: ", file.closed)