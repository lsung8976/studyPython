#try except else구문으로 예외를 처리합니다.
try:
    #숫자로 변환합니다.
    number_input_a = int(input("정수입력>"))
except:
    print("정수를 입력하지 않았습니다.")
else:
    print("원의 반지름:", number_input_a)
    print("원의 둘레:", 3.14 * 2 * number_input_a)
    print("원의 넓이:", 3.14 * (number_input_a ** 2))
