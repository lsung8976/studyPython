import test_module as test

radius = test.number_input()

print(test.get_circumferenece(radius))
print(test.get_circle_area(radius))