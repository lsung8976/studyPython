PI = 3.141592

def number_input():
    output = input("숫자입력>")
    return float(output)

def get_circumferenece(radius):
    return 2 * PI * radius

def get_circle_area(radius):
    return PI * radius * radius

if __name__ == "__main__":
    print("get_circumferenece(10):", get_circumferenece(10))
    print("get_circle_area(10):", get_circle_area(10))