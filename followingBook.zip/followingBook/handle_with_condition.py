
user_input_a = input("정수입력>")

if user_input_a.isdigit():
    #출력합니다.
    
    print("원의 반지름:", user_input_a)
    print("원의 둘레:", user_input_a * 2 * 3.14)
    print("원의 반지름:", 3.14 * (user_input_a ** 2))
else:
    print("정수를 입력하지 않았습니다.")
