number = input("정수 입력> ")
number = int(number)

#조건문 사용
if number > 0 :
    #pass로 치환가능!!!
    #양수일때 : 아직 미구현 상태입니다.
    raise NotImplementedError
else:
    raise NotImplementedError
    #음수일때 : 아직 미구현 상태입니다.]