#반복 변수를 기반으로 반복하기
i = 0
while i < 10:
    print("{}번째 반복입니다.".format(i))
    i += 1