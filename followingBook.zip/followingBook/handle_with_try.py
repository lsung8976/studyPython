#try except 구문으로 예외를 처리합니다.
try:
    #숫자로 변환합니다.
    number_input_a = int(input("정수입력>"))
    #출력합니다.
    print("원의 반지름:", number_input_a)
    print("원의 둘레:", number_input_a * 2 * 3.14)
    print("원의 반지름:", 3.14 * (number_input_a ** 2))
except:
    print("무언가 잘못되었습니다.")