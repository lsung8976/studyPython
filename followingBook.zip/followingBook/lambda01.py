#함수를 선언합니다.
power = lambda x : x * x
under_3 = lambda x : x < 3

#변수를 선언합니다.
list_input_a = [1, 2, 3, 4, 5]

#map()함수를 사용합니다.    //일반 식을 반환하는 함수를 매개변수로 가짐
output_a = map(power, list_input_a)
print("#map() 함수의 실행 결과")
print("map(power, list_input_a): ", output_a)
print("map(power, list_input_a): ", list(output_a))
print()

#filter()함수를 사용합니다. //불 식을 반환 하는 함수를 매개변수로 가짐
output_b = filter(under_3, list_input_a)
print("filter()함수의 실행결과")
print("filter(under_3, list_input_a):", output_b)
print("filter(under_3, list_input_a):", list(output_b))
print()