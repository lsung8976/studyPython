#학생리스트를 선언합니다.
students = [
    { "name" : "윤인성", "Korean": 87, "math" : 98, "english" : 88, "science" : 95},
    { "name" : "연하진", "Korean": 92, "math" : 98, "english" : 96, "science" : 98},
    { "name" : "구지연", "Korean": 76, "math" : 96, "english" : 94, "science" : 90},
    { "name" : "나선주", "Korean": 98, "math" : 92, "english" : 96, "science" : 92},
    { "name" : "윤아린", "Korean": 95, "math" : 98, "english" : 98, "science" : 98},
    { "name" : "윤명월", "Korean": 64, "math" : 88, "english" : 92, "science" : 92}
]

#print(students[2]["Korean"]) 구지연의 한국어점수

#학생을 한 명씩 반복합니다.
print("이름", "총점", "평균", sep = "\t")

for student in students:
    #점수의 총합과 평균을 구합니다.
    score_sum = student["Korean"] + student["math"] +\
        student["english"] + student["science"]
    score_average = score_sum / 4
    #출력합니다.
    print(student["name"], score_sum, score_average, sep = "\t")