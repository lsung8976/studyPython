a, b = 10, 20
print("교환 전 값")
print("a : ", a)
print("b : ", b)
print()

a, b = b, a
#값을 교환합니다.
print("#교환후 값")
print("a : ", a)
print("b : ", b)
print()