def return_test():
    return

value = return_test()
print(value)