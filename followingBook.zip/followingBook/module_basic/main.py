import test_module

print("#메인의 __name__ 출력하기")
print(__name__)
print()