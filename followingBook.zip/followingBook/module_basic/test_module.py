print("#모듈의 __name__출력하기")
print(__name__)
print()