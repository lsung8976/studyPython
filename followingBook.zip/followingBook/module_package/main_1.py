from test_package import *

print(module_a.varaiable_a)
print(module_b.varaiable_b)