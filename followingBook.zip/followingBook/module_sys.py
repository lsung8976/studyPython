import sys
print(sys.argv)
print("---")

print("getwindowversion:()", sys.getprofile())
print("---")
print("copyright:", sys.copyright)
print("---")
print("version:", sys.version)

sys.exit()