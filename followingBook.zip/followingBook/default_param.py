def print_n_times(value, n = 2):
    #n번 반복합니다.
    for i in range(n):
        print(value)
    

#함수를 호출합니다.
print_n_times("안녕하세요")

def print_N_times(value, n = 2):
    #N*2 번 반복합니다.
    for i in range(n * 2):
        print(value)

print(value, 2)