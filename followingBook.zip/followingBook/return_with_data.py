def return_test():
    return 100

value = return_test()
print(value)