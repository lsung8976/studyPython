#try except 구문으로 예외로 처리합니다.

try:
    #숫자로 변환합니다.
    number_input_a = int(input("정수입력 > "))
    #출력합니다.
    print("원의 반지름:", number_input_a)
    print("원의 둘레:", 3.14 * 2 * number_input_a)
    print("원의 넓이:", 3.14 * (number_input_a ** 2))
except Exception as exception:
    #예외 객체를 출력해봅니다.
    print("type(exception):", type(exception))
    print("exception:", exception)
"""
try:
    number_input_a = int(input("정수입력:"))

    print("원의 반지름:", number_input_a)
    print("원의 반지름:", number_input_a * 2 * 3.14)
    print("원의 반지름:", number_input_a ** 2 * 3.14)

except Exception as exception:
    print("type(exception):", type(exception))
    print("exception:", exception)"""