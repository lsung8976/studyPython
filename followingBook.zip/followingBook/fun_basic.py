def print_3_time():
    print("안녕하세요")
    print("안녕하세요")
    print("안녕하세요")

print_3_time()

def print_4_time():
    for i in range(4):
        print("야호")

print_4_time()