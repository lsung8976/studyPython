#역반복문
for i in reversed(range(5)):
    print("현재 반복 변수 : {}".format(i))