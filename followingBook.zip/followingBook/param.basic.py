def print_n_times(value, n):
    for i in range(n):
        print(value)

print_n_times("안녕하세요", 5)