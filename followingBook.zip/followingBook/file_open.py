"""
#파일을 엽니다.
file = open("basic.txt", "w")

#파일에 텍스트를 씁니다.
for i in range(1000):
    file.write("Hello Python Programming..!\t")

#파일을 닫습니다.
file.close()

#open close 없이 하는법

with open("basic.txt", "w") as file:
    file.write("Hello Python Programming..!\t")
"""

#파일을 엽니다.
file = open("basic.txt", "w")

for i in range(1000):
    file.write("Hello Python Programming..!\t")

file.close()