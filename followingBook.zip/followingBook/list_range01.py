array = [273, 32, 103 ,57 ,52]

for i in range(len(array)):
    #출력합니다.
    print("{}")