numbers = [1, 2, 3, 4, 5, 6]

r_num = reversed(numbers)

print("reversed_number :", r_num)
print(next(r_num))
print(next(r_num))
print(next(r_num))
print(next(r_num))
print(next(r_num))
print(next(r_num))