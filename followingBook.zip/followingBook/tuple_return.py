#함수를 선언합니다.
def test():
    return (10, 20)

a, b = test()

#출력합니다.
print("a :", a)
print("b :", b)

#함수를 선언합니다.
def test():
    return (10,20)

a,b = test()

print("a :", a)
print("b :"