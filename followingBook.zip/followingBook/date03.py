import datetime

now = datetime.datetime.now()

if now.month == 12 or (1 <= now.month < 3):
    print("지금은 겨울입니다.")
elif 3 <= now.month < 6:
    print("지금은 봄입니다.")
elif 6 <= now.month < 9:
    print("지금은 여름입니다.")
elif 9 <= now.month < 12:
    print("지금은 가을입니다.")

    