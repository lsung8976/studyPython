number = int(input("정수 입력>"))

if number%2 == 0:
    print("""입력한 문자열은 {}입니다.
{}는 짝수입니다.""".format(number, number))
else:
    print("""입력한 문자열은 {}입니다.
{}는 홀수입니다.""".format(number, number))

#들여쓰기가 안돼서 코드가 복잡해짐