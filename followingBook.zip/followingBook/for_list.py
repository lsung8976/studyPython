array = [273, 32, 103, 57, 52]

for element in array:
    print(element)

for i in range(len(array)):
    #출력합니다.
    print("{}번째 반복 : {}".format(i, array[i]))