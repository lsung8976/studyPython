try:
    file = open("info.txt", "w")
    file.close()
except Exception as e:
    print(e)

print("#파일이 제대로 닫힘?")
print("file.closed :",file.closed)