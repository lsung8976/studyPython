num = input()

dp = []
#d p[0] = 0 # 빈공간


dp[1] = 1
def func(i):
    if int(num[i:i+1]) <= 26 :
        dp[i] = 2
    else:
        dp[i] = 1

func(2)>

print(dp[0], dp[1], dp[2])