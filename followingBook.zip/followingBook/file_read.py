with open("basic.txt", "r") as file:
    contents = file.read()
print(contents)