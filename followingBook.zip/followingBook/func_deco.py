def test(function):
    def wrapper():
        print("인사가 시작되었습니다.")
        function()
        print("함수가 끝났습니다.")
    return wrapper

@test
def hello():
    print("hello")

hello()